<?php
include "Client.php";
class ClientConfiguration extends Client{
    private $SMTPHost;
    private $SMTPUsername;
    private $SMTPPassword;
    private $SMTPPort;
    private $TrackingEmailTemplate;
    private $TrackingEmailEventTemplate;
}
?>