<?php
require 'Conexao.php';
class Client{

    public function login($email,$password){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM CLIENT WHERE email= :email AND password = (SELECT dbo.fun_encriptar(:password));";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("email",$email);
        $sql->bindValue("password",$password);
        $sql->execute();
        $dado=$sql->fetch();
        if($dado[0]>0){
            $buscar="SELECT * FROM CLIENT WHERE email= :email AND password = (SELECT dbo.fun_encriptar(:password));";
            $sql=$Conexao->prepare($buscar);
            $sql->bindValue("email",$email);
        $sql->bindValue("password",$password);
            $sql->execute();
            $dado=$sql->fetch();
            $_SESSION["idusuario"]=$dado['ID'];
            return true;
        }else{
            return false;
        }
    }
    public function lembrarAcesso(){
        $Conexao    = Conexao::getConnection();
        $inserir="UPDATE Client SET ACESSTOKEN= :acesstoken WHERE ID = :id;";
        $token = sha1( uniqid( mt_rand() + time(), true ) );
        $expire = ( time() + ( 30 * 24 * 3600 ) );
        setcookie( "auth", json_encode( $token ), $expire);
        $sql=$Conexao->prepare($inserir);
        $sql->bindValue("acesstoken",$token);
        $sql->bindValue("id",$_SESSION["idusuario"]);
        $sql->execute();
    }
    public function procurarAcesso(){
        if(isset($_COOKIE["auth"])){
            $Conexao    = Conexao::getConnection();
            $contar="SELECT COUNT(*) FROM Client WHERE ACESSTOKEN = :acesstoken;";
            $sql=$Conexao->prepare($contar);
            $sql->bindValue("acesstoken",json_decode($_COOKIE["auth"]));
            $sql->execute();
            $dado=$sql->fetch();
            if($dado[0]>0){
                $buscar="SELECT * FROM Client WHERE ACESSTOKEN= :acesstoken;";
                $sql=$Conexao->prepare($buscar);
                $sql->bindValue("acesstoken",json_decode($_COOKIE["auth"]));
                $sql->execute();
                $dado=$sql->fetch();
                $_SESSION["idusuario"]=$dado['ID'];
                return true;
            }
        }
        return false;
    }
    public function gerar_senha($tamanho, $maiusculas, $minusculas, $numeros, $simbolos){
        $ma = "ABCDEFGHIJKLMNOPQRSTUVYXWZ"; // $ma contem as letras maiúsculas
        $mi = "abcdefghijklmnopqrstuvyxwz"; // $mi contem as letras minusculas
        $nu = "0123456789"; // $nu contem os números
        $si = "!@#$%¨&*()_+="; // $si contem os símbolos
        $senha="";
        if ($maiusculas){
              // se $maiusculas for "true", a variável $ma é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($ma);
        }
      
          if ($minusculas){
              // se $minusculas for "true", a variável $mi é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($mi);
          }
      
          if ($numeros){
              // se $numeros for "true", a variável $nu é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($nu);
          }
      
          if ($simbolos){
              // se $simbolos for "true", a variável $si é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($si);
          }
      
          // retorna a senha embaralhada com "str_shuffle" com o tamanho definido pela variável $tamanho
          return substr(str_shuffle($senha),0,$tamanho);
      }
    public function email($para_email,$config) {
        require 'PHPMailer/PHPMailerAutoLoad.php';
        $mail=new PHPMailer;
        $mail->isSMTP();

        $mail->Host=$config['SMTPHOST'];
        $mail->Port=$config['SMTPPORT'];
        $mail->SMTPSecure="tls";
        $mail->SMTPAuth="true";
        $mail->Username=$config['SMTPUSERNAME'];
        $mail->Password=$config['SMTPPASSWORD'];

        $mail->CharSet = 'UTF-8'; 
        
        $mail->setFrom($mail->Username,"Gustavo Sato");
        $mail->addAddress($para_email);
        $mail->Subject = $config['TRACKINGEMAILTEMPLATE'];
        $mail->IsHTML(true);
        $senha=$this->gerar_senha(10,true,true,true,false);
        $senhacss="<h2 style='color:red'><center>$senha</center></h2>";
        $mail->Body=$config['TRACKINGEMAILEVENTTEMPLATE'].$senhacss;
        $mail->Send();
        $Conexao    = Conexao::getConnection();
        $contar="SELECT * FROM Client WHERE ID = :id;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("id",$config['CLIENTID']);
        $sql->execute();
        $dado=$sql->fetch();
        $atualizar="UPDATE CLIENT SET PASSWORD = (SELECT dbo.fun_encriptar(:password));";
        $sql=$Conexao->prepare($atualizar);
        $sql->bindValue("password",$senha);
        $sql->execute();
    }
    public function verificarEmail($email){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM Client WHERE EMAIL = :email;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("email",$email);
        $sql->execute();
        $dado=$sql->fetch();
        if($dado[0]>0){
            $contar="SELECT * FROM Client WHERE EMAIL = :email;";
            $sql=$Conexao->prepare($contar);
            $sql->bindValue("email",$email);
            $sql->execute();
            $dado=$sql->fetch();
            $id=$dado['ID'];
            $buscar="SELECT * FROM ClientConfiguration WHERE CLIENTID= :clientid;";
            $sql=$Conexao->prepare($buscar);
            $sql->bindValue("clientid",$id);
            $sql->execute();
            return $sql->fetch();
        }
        return false;
    }
}
?>