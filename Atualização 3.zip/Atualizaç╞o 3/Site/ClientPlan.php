<?php

class ClientPlan{
    public function plano($id){
        $Conexao    = Conexao::getConnection();
        $achar="SELECT * FROM Planx WHERE ID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientid);";
        $sql=$Conexao->prepare($achar);
        $sql->bindValue("clientid",$id);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado;
    }
    public function receber_sms_credits($id){
        $Conexao    = Conexao::getConnection();
        $achar="SELECT * FROM ClientPlan WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($achar);
        $sql->bindValue("clientid",$id);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado['SMSCREDITS'];
    }
    public function padronizar($valor){
        echo 'R$ ';
        if($valor<1){
            $valor='0'.$valor;
        } 
        $result =str_replace('.',',',$valor);
        echo $result;
    }
    public function receberQuantidadePlano($idCliente,$plano){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID = :clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL != 'api/sms/send' AND YEAR(DT_REQUEST) = YEAR(GETDATE()) AND MONTH(DT_REQUEST) = MONTH(GETDATE());";
        else
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID = :clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL = 'api/sms/send' AND YEAR(DT_REQUEST) = YEAR(GETDATE()) AND MONTH(DT_REQUEST) = MONTH(GETDATE());";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("clientidd",$idCliente);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function receber_quantidade_plano_mes($idCliente,$plano,$mes){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM CLIENTAPIREQUEST WHERE DT_REQUEST > (SELECT EOMONTH(MIN(DT_REQUEST), :mes1) FROM CLIENTAPIREQUEST) AND DT_REQUEST <= (SELECT EOMONTH(MIN(DT_REQUEST), :mes2) FROM CLIENTAPIREQUEST) AND CLIENTID= :clientid AND RESPONSESTATUS = 200 AND URL != 'api/sms/send';";
        else
        $contar="SELECT COUNT(*) FROM CLIENTAPIREQUEST WHERE DT_REQUEST > (SELECT EOMONTH(MIN(DT_REQUEST), :mes1) FROM CLIENTAPIREQUEST) AND DT_REQUEST <= (SELECT EOMONTH(MIN(DT_REQUEST), :mes2) FROM CLIENTAPIREQUEST) AND CLIENTID= :clientid AND RESPONSESTATUS = 200 AND URL = 'api/sms/send';";
        $sql=$Conexao->prepare($contar);
        $mes2=$mes-1;
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindParam("mes1",$mes2,PDO::PARAM_INT);
        $sql->bindParam("mes2",$mes,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function receber_contagem_dia_semana($idCliente,$plano,$diferenca){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL != 'api/sms/send' AND DAY(DT_REQUEST) = DAY(DATEADD(DAY, :diferenca ,GETDATE())) AND MONTH(DT_REQUEST) = MONTH(DATEADD(DAY, :diferencaa ,GETDATE())) AND YEAR(DT_REQUEST) = YEAR(DATEADD(DAY, :diferencaaa,GETDATE()));";
        else
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL = 'api/sms/send' AND DAY(DT_REQUEST) = DAY(DATEADD(DAY, :diferenca ,GETDATE())) AND MONTH(DT_REQUEST) = MONTH(DATEADD(DAY, :diferencaa ,GETDATE())) AND YEAR(DT_REQUEST) = YEAR(DATEADD(DAY, :diferencaaa,GETDATE()));";
        //AND MONTH(DT_REQUEST) = MONTH(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)) AND DAY(DT_REQUEST) = DAY(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103));" CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("clientidd",$idCliente);
        $sql->bindParam("diferenca",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaa",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaaa",$diferenca,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function definir_meses($idCliente){
        $Conexao    = Conexao::getConnection();
        $quantidadeMeses="SELECT DATEDIFF(MONTH,(SELECT EOMONTH(MIN(DT_REQUEST),-1) FROM CLIENTAPIREQUEST WHERE CLIENTID=:clientid),EOMONTH(GETDATE()));";
        $sql=$Conexao->prepare($quantidadeMeses);
        $sql->bindValue("clientid",$idCliente);
        $sql->execute();
        $dado=$sql->fetch();
        return intval($dado[0]);
    }
    public function receber_mes($idCliente,$mes){
        $Conexao    = Conexao::getConnection();
        $mostrar="SELECT RIGHT('0'+ CAST(MONTH(EOMONTH(MIN(DT_REQUEST),:mes)) AS VARCHAR(2)),2)+'/'+CAST(YEAR(EOMONTH(MIN(DT_REQUEST),:mess)) AS CHAR(4)) FROM CLIENTAPIREQUEST WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($mostrar);
        $sql->bindParam("mes",$mes,PDO::PARAM_INT);
        $sql->bindParam("mess",$mes,PDO::PARAM_INT);
        $sql->bindParam("clientid",$idCliente,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
}
?>