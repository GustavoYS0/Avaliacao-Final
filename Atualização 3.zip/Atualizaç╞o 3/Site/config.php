<?php
define('DB_HOST'        , "DESKTOP-5JQEKGD\SQLEXPRESS");
define('DB_USER'        , "adm");
define('DB_PASSWORD'    , "adm");
define('DB_NAME'        , "sqlBD");
define('DB_DRIVER'      , "sqlsrv");
require 'Conexao.php';
if(!isset($_SESSION["idusuario"])){
    header('Location: login.php?s=c');
    exit();
}
require 'ClientApi.php';
$idUsuario=$_SESSION["idusuario"];
$clientApi=new ClientApi();
$nome    = Conexao::receber_nome_cliente($idUsuario);
$apis=$clientApi->receber_apis();
$apiids=$clientApi->receber_clients_api($idUsuario);
$contador=0;
$vetor=array();
$vetor2=array();
foreach($apis as $api){
  $i=1;
  foreach($apiids as $apiid){
      if($api['ID']==$apiid['APIID']){
          $i=0;
      }
  }
  if($i){
      $vetor[$contador]=$api['NAME'];
      $vetor2[$contador]=$api['ID'];
      $contador++;
  }
}
$recebeu=isset($_POST['seleciona']) ? $_POST['seleciona']:$vetor2[0];
$recebeu2=isset($_POST['user']) ? $_POST['user']:'';
$recebeu3=isset($_POST['remover']) ? $_POST['remover']:'';
if(!empty($recebeu2) || !empty($recebeu3)){
  if($recebeu2)
    $clientApi->inserir_client_api($idUsuario,$recebeu,$_POST['user'],$_POST['password']);
  if(!empty($recebeu3))
    $clientApi->remover_client_api($idUsuario,intval($recebeu3));
  $apiids=$clientApi->receber_clients_api($idUsuario);
  $contador=0;
  foreach($apis as $api){
    $i=1;
    foreach($apiids as $apiid){
        if($api['ID']==$apiid['APIID']){
            $i=0;
        }
    }
    if($i){
        $vetor[$contador]=$api['NAME'];
        $vetor2[$contador]=$api['ID'];
        $contador++;
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Configurações | Expresso API</title>

  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/expressoapiconfig.css" rel="stylesheet">
  <link href="css/expressoapi.css" rel="stylesheet">
  
  <style type="text/css">




.ui-w-80 {
width: 80px !important;
height: auto;
}

.btn-default {
border-color: rgba(24,28,33,0.1);
background: rgba(0,0,0,0);
color: #4E5155;
}

.btn-default:hover {
border-color: rgba(24,28,33,0.1);
background: #faeded;
color: #6e6f70;
}

label.btn {
margin-bottom: 0;
}

.btn-outline-primary {
border-color: #cd3232;
background: transparent;
color: #cd3232;
}

.btn-outline-primary:hover {
border-color: #cd3232;
background: #cd3232;
color: #fff;
}

.btn {
cursor: pointer;
}

.text-light {
color: #babbbc !important;
}

.btn-facebook {
border-color: rgba(0,0,0,0);
background: #3B5998;
color: #fff;
}

.btn-instagram {
border-color: rgba(0,0,0,0);
background: #000;
color: #fff;
}

.card {
background-clip: padding-box;
box-shadow: 0 1px 4px rgba(24,28,33,0.012);
}

.row-bordered {
overflow: hidden;
}

.account-settings-fileinput {
position: absolute;
visibility: hidden;
width: 1px;
height: 1px;
opacity: 0;
}
.account-settings-links .list-group-item.active {
font-weight: bold !important;
}
html:not(.dark-style) .account-settings-links .list-group-item.active {
background: transparent !important;
}
.account-settings-multiselect ~ .select2-container {
width: 100% !important;
}
.light-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24, 28, 33, 0.03) !important;
}
.light-style .account-settings-links .list-group-item.active {
color: #4e5155 !important;
}
.material-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24, 28, 33, 0.03) !important;
}
.material-style .account-settings-links .list-group-item.active {
color: #4e5155 !important;
}
.dark-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(255, 255, 255, 0.03) !important;
}
.dark-style .account-settings-links .list-group-item.active {
color: #fff !important;
}
.light-style .account-settings-links .list-group-item.active {
color: #4E5155 !important;
}
.light-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24,28,33,0.03) !important;
}



</style>

</head>

<body id="page-top">

  <div id="wrapper">

    <ul class="barranav bg-gradiente-um painel painel-negro accordion" id="accordionPainel">


      <a class="painel-marca d-flex alinha-item-centro justificado-conteudo-centro" href="index.php">
        <div class="painel-marca-icon ">
          <i class="fas fa-truck"></i>
        </div>
        <div class="painel-marca-texto margem3">Expresso API </div>
      </a>

      <hr class="painel-divisor margem0">

      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>Dashboard</span></a>
      </li>

      <hr class="painel-divisor">
      
      <div class="painel-titulo">
        Opções
     
      <li class="nav-item">
        <a class="nav-link collapsed" href="config.html">
          <i class="fas fa-fw fa-cog"></i>
          <span>Configurações</span>
        </a>
        <a class="nav-link collapsed" href="login.html">
          <i class="fas fa-sign-out-alt"></i>
          <span>Log out</span>
        </a>
      </li>

      <hr class="painel-divisor nenhum md-block">

    </ul>
   
    <div id="content-wrapper" class="d-flex col-flex">

      <div id="content">

        <nav class="navbar navbar-expand navbar-light bg-branco topbar margem4 static-top sombra">

          <ul class="barranav margem1-auto">

            <li class="nav-item semseta">
              <div class="nav-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="margem2-1 nenhum d-lg-nalinha texto-cinza-6 pqno"><?php echo $nome; ?></span>
              </div>
            </li>
          </ul>
        </nav>
  
        <div class="container light-style flex-grow-1 container-p-y">

          <h1 class="h3 margem0-1 texto-cinza-8">Configurações</h1>
          <br>
        
          <div class="card overflow-hidden">
            <div class="row no-gutters row-bordered row-border-light">
              <div class="col-md-3 pt-0">
                <div class="list-group list-group-flush account-settings-links">
                  <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">Gerais</a>
                  
                </div>
              </div>
                <div class="col-md-9">
                  <div class="tab-content">
                    <div class="tab-pane fade active show" id="account-general">
                      <div class="card-body pb-2">
                        <div class="form-group">
                          <label class="form-label">Selecione abaixo o provedor:</label>
                          <form action="config.php" method="post">
                              <select class="custom-select" name="seleciona" onchange="this.form.submit()">
                                  <?php 
                                  for($a=0;$a<$contador;$a++){
                                    if($vetor2[$a]==$recebeu){
                                      echo "<option value='$vetor2[$a]' selected>$vetor[$a]</option>";
                                    }else{
                                      echo "<option value='$vetor2[$a]'>$vetor[$a]</option>";
                                    }
                                    }
                                      ?>
                                </select>
                                </form>
                        </div>
                        <div class="form-group">
                        <div class="text-center">
     
                          <a href="#myModal" data-toggle="modal"><input type="submit" class="btn btn-outline-primary" value="Adicionar">&nbsp;</a>
                        </div>
                        <div id="myModal" class="modal fade">
                          <div class="modal-dialog modal-login">
                            <div class="modal-content">
                              <form action="config.php" method="post">
                                <div class="modal-header">				
                                  <h4 class="modal-title">Adicionar</h4>
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">				
                                  <div class="form-group">
                                    <label>Usuário</label>
                                    <input type="text" class="form-control" required="required" name="user">
                                  </div>
                                  <div class="form-group">
                                    <div class="clearfix">
                                      <label>Senha</label><input type="text" class="form-control" required="required" name="password">
                                      </div><br>
                                    
                                    
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <input type="submit" class="btn btn-primeiro pull-right" value="Adicionar">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>  
                        </div>   
                        
                        <div>
                          <br>
                          <label class="form-label">Seus provedores:</label>
                          </div>
                        </div>
                      
                        <section class="pb-5 header ">
                          
                                  
                                      
                        
                                              <div class="table-responsive">
                                                  <table class="table m-0">
                                                      <thead>
                                                          <tr>
                                                              <th style="color:#FF0000" scope="col">#</th>
                                                              <th style="color:#FF0000" scope="col">Provedor</th>
                                                              <th style="color:#FF0000" scope="col">Usuário</th>
                                                              <th style="color:#FF0000" scope="col">Senha</th>
                                                              <th style="color:#FF0000" scope="col">Remover?</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                      <?php 
                                                      $c=0;
                                                      foreach($apiids as $apiid){
                                                        $c++;
                                                        $r=$clientApi->receber_nome_api($apiid['APIID']);
                                                        ?>
                                                          <tr>
                                                              <th scope="row"><?php echo $c;?></th>
                                                              <td><?php echo $r; ?></td>
                                                              <td><?php echo $apiid['USERNAME']; ?></td>
                                                              <td><?php echo $apiid['PASSWORD']; ?></td>
                                                              <td>
                                                                  
                                                                  <ul class="list-inline m-0">
                                                                          <li class="list-inline-item">
                                                                          <form action="config.php" method="post">
                                                                          <button class="btn btn-danger btn-sm rounded-0" type="submit" data-toggle="tooltip" data-placement="top" title="Remover" name="remover" value="<?php echo $apiid['APIID']; ?>"><i class="fa fa-trash"></i></button>
                                                                          </form>
                                                                      </li>
                                                                  </ul>
                                                              </td>
                                                          </tr>
                                                      <?php } ?>
                                                      </tbody>
                                                      
                                                  </table>
                        
                                          
                                      </div>
                                  </div>
                             
                        </section>

                    </div>
                    
                  
                </div>
              </div>
            </div>
        <br>
            <!-- <div class="text-right mt-3">
              <button type="button" class="btn btn-outline-primary">Salvar alterações</button>&nbsp;
              <button type="button" class="btn btn-default">Cancelar</button>
            </div> -->
        
          </div>
                 
              


      
      <footer class="adesivo-rodape bg-branco">
        <div class="container margem-auto1">
          <div class="copyright texto-centro my-auto">
            <span>Copyright &copy; Expresso API 2020</span>
          </div>
        </div>
      </footer>

    </div>

  </div>

  <a class="scroll-to-top arredondado" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>



  <script src="vendor/jquery/jquery.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.js"></script>
  <script src="javascript/expressoapi.js"></script>
  <script src="javascript/expressoapiconfig.js"></script>
  <script src="javascript/BSexpressoapiconfig.js"></script>
  <script src="javascript/removeitem.js"></script>
  <script type="text/javascript">

  </script>

</body>

</html>
