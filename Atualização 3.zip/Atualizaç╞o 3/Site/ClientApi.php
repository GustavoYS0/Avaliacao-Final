<?php
class ClientApi{
    public function receber_apis(){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT * FROM API;";
        $sql=$Conexao->prepare($contar);
        $sql->execute();
        return $sql->fetchAll();
    }
    public function receber_clients_api($idCliente){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT APIID,CLIENTID,USERNAME,PASSWORD FROM CLIENTAPI WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->execute();
        return $sql->fetchAll();
    }
    public function receber_nome_api($idApi){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT NAME FROM API WHERE ID = :apiid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado['NAME'];
    }
    public function inserir_client_api($idCliente,$idApi,$usuario,$senha){
        $Conexao    = Conexao::getConnection();
        $contar="INSERT INTO CLIENTAPI
        (CLIENTID,APIID,USERNAME,PASSWORD) VALUES
        (:clientid,:apiid,:username,:password);";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->bindValue("username",$usuario);
        $sql->bindValue("password",$senha);
        $sql->execute();
    }
    public function remover_client_api($idCliente,$idApi){
        $Conexao    = Conexao::getConnection();
        $contar="DELETE FROM CLIENTAPI WHERE CLIENTID = :clientid AND APIID = :apiid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->execute();
    }
}
?>