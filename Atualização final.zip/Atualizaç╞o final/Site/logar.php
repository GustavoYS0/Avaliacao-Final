<?php
require 'banco/Controller/ControllerLogin.php';
$controllerLogin=new ControllerLogin();
$controllerLogin->preparar_login();
$controllerLogin->mostrar_mensagem_erro();
?>