<?php
require 'banco/Controller/ControllerRecuperar.php';
$controllerRecuperar=new ControllerRecuperar();
$controllerRecuperar->inicia_recuperar();
$controllerRecuperar->mostrar_dados();
?>
