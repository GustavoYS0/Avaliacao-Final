<?php
require 'banco/Controller/ControllerDetalhes.php';
$controllerDetalhes=new ControllerDetalhes();
$controllerDetalhes->inicia_detalhes();
$controllerDetalhes->mostrar_dados();
?>