<?php
class ViewRecuperar{
    public function mostrar_aviso($aviso){
        $html = file_get_contents('html/recuperarsenha.html');
        $html = str_replace('{aviso}',$aviso,$html);
        print $html;
    }
}
?>