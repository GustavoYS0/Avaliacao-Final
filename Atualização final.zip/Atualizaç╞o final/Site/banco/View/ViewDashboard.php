<?php
class ViewDashboard{
    public function definir_index(){
        return file_get_contents('html/index.html');
    }
    public function alterar($dado,$html,$nome){
        $html = str_replace($nome,$dado,$html);
        return $html;
    }
    public function mostrar($html){
        print $html;
    }
}
?>