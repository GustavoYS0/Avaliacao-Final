<?php
class ViewConfig{
    public function definir_config(){
        return file_get_contents('html/config.html');
    }
    public function alterar($dado,$html,$nome){
        $html = str_replace($nome,$dado,$html);
        return $html;
    }
    public function mostrar($html){
        print $html;
    }
}
?>