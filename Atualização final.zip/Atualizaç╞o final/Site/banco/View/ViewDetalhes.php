<?php
class ViewDetalhes{
    public function definir_detalhes(){
        return file_get_contents('html/detalhes.html');
    }
    public function alterar($dado,$html,$nome){
        $html = str_replace($nome,$dado,$html);
        return $html;
    }
    public function mostrar($html){
        print $html;
    }
}
?>