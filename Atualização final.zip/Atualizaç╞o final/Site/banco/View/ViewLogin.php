<?php
class ViewLogin{
    public function mostrar_erro($erro){
        $html = file_get_contents('html/login.html');
        $html = str_replace('{erro}',$erro,$html);
        print $html;
    }
}
?>