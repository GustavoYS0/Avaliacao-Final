<?php

class ClientPlan{
    private $idusuario;
    private $mes;
    public function getIdusuario(){
        return $this->idusuario;
    }
    public function plano($id){
        $Conexao    = Conexao::getConnection();
        $achar="SELECT * FROM Planx WHERE ID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientid);";
        $sql=$Conexao->prepare($achar);
        $sql->bindValue("clientid",$id);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado;
    }
    public function receber_sms_credits($id){
        $Conexao    = Conexao::getConnection();
        $achar="SELECT * FROM ClientPlan WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($achar);
        $sql->bindValue("clientid",$id);
        $sql->execute();
        $dado=$sql->fetch();
        if($dado)
        return $dado['SMSCREDITS'];
        return 0;
    }
    public function padronizar($valor){
        echo 'R$ ';
        if($valor<1){
            $valor='0'.$valor;
        } 
        $result =str_replace('.',',',$valor);
        echo $result;
    }
    public function receberQuantidadePlano($idCliente,$plano){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID = :clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL != 'api/sms/send' AND YEAR(DT_REQUEST) = YEAR(GETDATE()) AND MONTH(DT_REQUEST) = MONTH(GETDATE());";
        else
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID = :clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL = 'api/sms/send' AND YEAR(DT_REQUEST) = YEAR(GETDATE()) AND MONTH(DT_REQUEST) = MONTH(GETDATE());";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("clientidd",$idCliente);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function receber_quantidade_plano_mes($idCliente,$plano,$mes){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM CLIENTAPIREQUEST WHERE DT_REQUEST > (SELECT EOMONTH(MIN(DT_REQUEST), :mes1) FROM CLIENTAPIREQUEST) AND DT_REQUEST <= (SELECT EOMONTH(MIN(DT_REQUEST), :mes2) FROM CLIENTAPIREQUEST) AND CLIENTID= :clientid AND RESPONSESTATUS = 200 AND URL != 'api/sms/send';";
        else
        $contar="SELECT COUNT(*) FROM CLIENTAPIREQUEST WHERE DT_REQUEST > (SELECT EOMONTH(MIN(DT_REQUEST), :mes1) FROM CLIENTAPIREQUEST) AND DT_REQUEST <= (SELECT EOMONTH(MIN(DT_REQUEST), :mes2) FROM CLIENTAPIREQUEST) AND CLIENTID= :clientid AND RESPONSESTATUS = 200 AND URL = 'api/sms/send';";
        $sql=$Conexao->prepare($contar);
        $mes2=$mes-1;
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindParam("mes1",$mes2,PDO::PARAM_INT);
        $sql->bindParam("mes2",$mes,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function receber_contagem_dia_semana($idCliente,$plano,$diferenca){
        $Conexao    = Conexao::getConnection();
        if($plano)
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL != 'api/sms/send' AND DAY(DT_REQUEST) = DAY(DATEADD(DAY, :diferenca ,GETDATE())) AND MONTH(DT_REQUEST) = MONTH(DATEADD(DAY, :diferencaa ,GETDATE())) AND YEAR(DT_REQUEST) = YEAR(DATEADD(DAY, :diferencaaa,GETDATE()));";
        else
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = (SELECT PLANID FROM ClientPlan WHERE CLIENTID = :clientidd) AND RESPONSESTATUS = 200 AND URL = 'api/sms/send' AND DAY(DT_REQUEST) = DAY(DATEADD(DAY, :diferenca ,GETDATE())) AND MONTH(DT_REQUEST) = MONTH(DATEADD(DAY, :diferencaa ,GETDATE())) AND YEAR(DT_REQUEST) = YEAR(DATEADD(DAY, :diferencaaa,GETDATE()));";
        //AND MONTH(DT_REQUEST) = MONTH(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)) AND DAY(DT_REQUEST) = DAY(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103));" CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("clientidd",$idCliente);
        $sql->bindParam("diferenca",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaa",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaaa",$diferenca,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function definir_meses($idCliente){
        $Conexao    = Conexao::getConnection();
        $quantidadeMeses="SELECT DATEDIFF(MONTH,(SELECT EOMONTH(MIN(DT_REQUEST),-1) FROM CLIENTAPIREQUEST WHERE CLIENTID=:clientid),EOMONTH(GETDATE()));";
        $sql=$Conexao->prepare($quantidadeMeses);
        $sql->bindValue("clientid",$idCliente);
        $sql->execute();
        $dado=$sql->fetch();
        return intval($dado[0]);
    }
    public function receber_mes($idCliente,$mes){
        $Conexao    = Conexao::getConnection();
        $mostrar="SELECT RIGHT('0'+ CAST(MONTH(EOMONTH(MIN(DT_REQUEST),:mes)) AS VARCHAR(2)),2)+'/'+CAST(YEAR(EOMONTH(MIN(DT_REQUEST),:mess)) AS CHAR(4)) FROM CLIENTAPIREQUEST WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($mostrar);
        $sql->bindParam("mes",$mes,PDO::PARAM_INT);
        $sql->bindParam("mess",$mes,PDO::PARAM_INT);
        $sql->bindParam("clientid",$idCliente,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function iniciar_index(){
        require 'Conexao/Conexao.php';
        if(!isset($_SESSION["idusuario"])){
            header('Location: logar.php');
            exit();
        }
        $this->idusuario=$_SESSION["idusuario"];
    }
    public function quantidade_extra($quantidadePlan,$quantidadeContratada){
        if($quantidadePlan>$quantidadeContratada)
        return $quantidadePlan-$quantidadeContratada;
        return 0;
    }
    public function quantidade_disponivel($quantidadePlan,$quantidadeContratada){
        if($quantidadePlan>$quantidadeContratada)
        return 0;
        return $quantidadeContratada-$quantidadePlan;
    }
    public function total($quantidadePlan,$quantidadeContratada,$plano,$quantidadeExtra){
        if($quantidadePlan>$quantidadeContratada)
        return $plano['PRICE']+(($plano['PRICE']/$quantidadeContratada)*$quantidadeExtra);
        return $plano['PRICE'];
    }
    /*
    if($quantidadePlano1>$quantidadeContratada1){
  $quantidadeExtra=$quantidadePlano1-$quantidadeContratada1;
  $quantidadeDisponivel1=0;
  $total1=$plano['PRICE']+(($plano['PRICE']/$quantidadeContratada1)*$quantidadeExtra);
}else{
  $total1=$plano['PRICE'];
  $quantidadeExtra=0;
  $quantidadeDisponivel1=$quantidadeContratada1-$quantidadePlano1;
}
    */
    public function receber_dia_semana(){
        date_default_timezone_set('America/Sao_Paulo');
        return date('w',strtotime(date('Y-m-d')));
    }
    public function rebeber_dias_semana($diasemana_numero,$dia){
        if($diasemana_numero==0){
            if($dia==0)
            return 0;
            return $dia-7;
        }else if($diasemana_numero==1){
            if($dia==0)
            return 6;
            return $dia-1;
        }else if($diasemana_numero==2){
            if($dia==0)
            return 5;
            return $dia-2;
        }else if($diasemana_numero==3){
            if($dia==0)
            return 4;
            return $dia-3;
        }else if($diasemana_numero==4){
            if($dia==0)
            return 3;
            return $dia-4;
        }else if($diasemana_numero==5){
            if($dia==0)
            return 2;
            return $dia-5;
        }else if($diasemana_numero==6){
            if($dia==0)
            return 1;
            return $dia-6;
        }
    }
    public function iniciar_detalhes(){
        require 'Conexao/Conexao.php';
if(!isset($_SESSION["idusuario"])){
    header('Location: logar.php?p=c');
    exit();
}
$this->idusuario=$_SESSION["idusuario"];
    }
    public function receber_selecao(){
        return isset($_POST['opcoes']) ? $_POST['opcoes']:"";
    }
    public function selecionado($plano){
        $recebeu=$this->receber_selecao();
if(empty($recebeu))
  return $this->receber_quantidade_plano_mes($this->idusuario,$plano,$this->definir_meses($this->idusuario)-1);
  return $this->receber_quantidade_plano_mes($this->idusuario,$plano,intval($recebeu)-1);
}
    public function receber_options_detalhes(){
$meses=$this->definir_meses($this->idusuario);
$recebeu=$this->receber_selecao();
$options='';
                          $meses--;
                           for($i=$meses;$i>-1;$i--){
                            $var=$this->receber_mes($this->idusuario,$i);
                            $ii=$i+1;
                          if(!empty($recebeu)){ 
                            if($i==intval($recebeu)-1){
                              $options .= '<option value='."'$ii'"." selected>$var</option>";
                              $this->mes=$var;
                            }else{
                            $options .= '<option value='."'$ii'".">$var</option>";
                            }
                          }else{
                            if($i==$meses){
                              $options .= '<option value='."'$ii'"." selected>$var</option>";
                              $this->mes=$var;
                            }else{
                              $options .= '<option value='."'$ii'".">$var</option>";
                            }
                          } }
                          return $options;
    }
public function getMes(){
    return $this->mes;
}
}
?>