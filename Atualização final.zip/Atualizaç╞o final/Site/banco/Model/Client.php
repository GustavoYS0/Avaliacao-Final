<?php
require 'Conexao/Conexao.php';
class Client{
    public function login($email,$password){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM CLIENT WHERE email= :email AND password = (SELECT dbo.fun_encriptarr(:password));";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("email",$email);
        $sql->bindValue("password",$password);
        $sql->execute();
        $dado=$sql->fetch();
        if($dado[0]>0){
            $buscar="SELECT * FROM CLIENT WHERE email= :email AND password = (SELECT dbo.fun_encriptarr(:password));";
            $sql=$Conexao->prepare($buscar);
            $sql->bindValue("email",$email);
        $sql->bindValue("password",$password);
            $sql->execute();
            $dado=$sql->fetch();
            $_SESSION["idusuario"]=$dado['ID'];
            return true;
        }else{
            return false;
        }
    }
    public function lembrarAcesso(){
        $Conexao    = Conexao::getConnection();
        $inserir="SELECT ACESSTOKEN FROM Client WHERE ID = :id;";
        $expire = ( time() + ( 30 * 24 * 3600 ) );
        $sql=$Conexao->prepare($inserir);
        $sql->bindValue("id",$_SESSION["idusuario"]);
        $sql->execute();
        $dado=$sql->fetch();
        setcookie( "auth", json_encode( $dado[0] ), $expire);
    }
    public function verificar_login(){
        if(isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password'])){
            $email=addslashes($_POST['email']);
            $password=addslashes($_POST['password']);
            if($this->login($email,$password)){
                if(isset($_SESSION['idusuario'])){
                    $lembrar = ( isset($_POST['lembrar']) ) ? true : null;
                    if($lembrar){
                        $this->lembrarAcesso();
                    }
                    header("Location: entrarIndex.php");
                    return '';
                }else{
                    return 'Sessão expirada!';
                }
            }else{
                return 'E-mail ou senha inválido(s)!';
            }
        }else{
            if(isset($_POST['email']) && isset($_POST['password']))
            return 'Adicione os campos de login e senha primeiro para poder acessar!';
        }
    }
    public function procurarAcesso(){
        if(isset($_COOKIE["auth"])){
            $Conexao    = Conexao::getConnection();
            $contar="SELECT COUNT(*) FROM Client WHERE ACESSTOKEN = :acesstoken;";
            $sql=$Conexao->prepare($contar);
            $sql->bindValue("acesstoken",json_decode($_COOKIE["auth"]));
            $sql->execute();
            $dado=$sql->fetch();
            if($dado[0]>0){
                $buscar="SELECT * FROM Client WHERE ACESSTOKEN= :acesstoken;";
                $sql=$Conexao->prepare($buscar);
                $sql->bindValue("acesstoken",json_decode($_COOKIE["auth"]));
                $sql->execute();
                $dado=$sql->fetch();
                $_SESSION["idusuario"]=$dado['ID'];
                return true;
            }
        }
        return false;
    }
    public function iniciar_login(){
        if(isset($_GET['c'])){
          setcookie( "auth",null,time()-1);
          session_unset ( );
        }else if($this->procurarAcesso()){
          if(isset($_GET['p'])){
            header('Location: entrarDetalhes.php');
          }else if(isset($_GET['s'])){
            header('Location: entrarConfig.php');
          }else{
            header('Location: entrarIndex.php');
          }
            exit();
        }
        if(isset($_SESSION["idusuario"])){
          header('Location: entrarIndex.php');
          exit();
      }
    }
    public function iniciar_recuperar(){
        if(isset($_SESSION["idusuario"])){
            header('Location: entrarIndex.php');
            exit();
        }
    }
    public function gerar_senha($tamanho, $maiusculas, $minusculas, $numeros, $simbolos){
        $ma = "ABCDEFGHIJKLMNOPQRSTUVYXWZ"; // $ma contem as letras maiúsculas
        $mi = "abcdefghijklmnopqrstuvyxwz"; // $mi contem as letras minusculas
        $nu = "0123456789"; // $nu contem os números
        $si = "!@#$%¨&*()_+="; // $si contem os símbolos
        $senha="";
        if ($maiusculas){
              // se $maiusculas for "true", a variável $ma é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($ma);
        }
      
          if ($minusculas){
              // se $minusculas for "true", a variável $mi é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($mi);
          }
      
          if ($numeros){
              // se $numeros for "true", a variável $nu é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($nu);
          }
      
          if ($simbolos){
              // se $simbolos for "true", a variável $si é embaralhada e adicionada para a variável $senha
              $senha .= str_shuffle($si);
          }
      
          // retorna a senha embaralhada com "str_shuffle" com o tamanho definido pela variável $tamanho
          return substr(str_shuffle($senha),0,$tamanho);
      }
    public function email($para_email) {
        require 'banco/Model/PHPMailer/PHPMailerAutoLoad.php';
        $mail=new PHPMailer;
        $mail->isSMTP();

        $mail->Host="smtp.gmail.com";
        $mail->Port=587;
        $mail->SMTPSecure="tls";
        $mail->SMTPAuth="true";
        $mail->Username="gysato3@gmail.com";
        $mail->Password="Gugu3961";

        $mail->CharSet = 'UTF-8'; 
        
        $mail->setFrom($mail->Username,"Gustavo Sato");
        $mail->addAddress($para_email);
        $mail->Subject = "Requisição de nova senha Expresso Api";
        $mail->IsHTML(true);
        $senha=$this->gerar_senha(10,true,true,true,false);
        $senhacss="<h2 style='color:red'><center>$senha</center></h2>";
        $mail->Body="<p style='color:red'>Foi solicitado uma nova senha para o Expresso Api, sua nova senha é:</p>".$senhacss;
        $mail->Send();
        $Conexao    = Conexao::getConnection();
        $contar="SELECT * FROM Client WHERE EMAIL = :email;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("email",$para_email);
        $sql->execute();
        $dado=$sql->fetch();
        $atualizar="UPDATE CLIENT SET PASSWORD = (SELECT dbo.fun_encriptarr(:password)) WHERE ID = :id;";
        $sql=$Conexao->prepare($atualizar);
        $sql->bindValue("password",$senha);
        $sql->bindValue("id",$dado['ID']);
        $sql->execute();
    }
    public function verificarEmail($email){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM Client WHERE EMAIL = :email;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("email",$email);
        $sql->execute();
        $dado=$sql->fetch();
        if($dado[0]>0){
            return true;
        }
        return false;
    }
    public function mostrar_aviso_recuperar(){
        if(isset($_GET['msg'])){
            $msg=$_GET['msg'];
            return "<p style='color:red'>$msg</p>";
        }
        return "<p class='margem4'>Ok... Essas coisas acontecem. Apenas informe seu endereço de e-mail abaixo
        e nós enviaremos uma nova senha para você!</p>";
    }
    public function enviar_email(){
        if(isset($_POST['email'])){
            $email=$_POST['email'];
            if($this->verificarEmail($email)){
                $this->email($email);
            }
            $msg='Se o e-mail informado for válido, enviaremos um e-mail com sua nova senha!';
            header("Location: recuperar.php?msg=$msg");
        }
    }
}
?>