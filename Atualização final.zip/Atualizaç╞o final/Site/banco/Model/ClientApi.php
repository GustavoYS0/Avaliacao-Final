<?php
class ClientApi{
    public function receber_apis(){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT * FROM API;";
        $sql=$Conexao->prepare($contar);
        $sql->execute();
        return $sql->fetchAll();
    }
    public function receber_clients_api($idCliente){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT APIID,CLIENTID,USERNAME,PASSWORD FROM CLIENTAPI WHERE CLIENTID = :clientid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->execute();
        return $sql->fetchAll();
    }
    public function receber_nome_api($idApi){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT NAME FROM API WHERE ID = :apiid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado['NAME'];
    }
    public function inserir_client_api($idCliente,$idApi,$usuario,$senha){
        $Conexao    = Conexao::getConnection();
        $contar="INSERT INTO CLIENTAPI
        (CLIENTID,APIID,USERNAME,PASSWORD) VALUES
        (:clientid,:apiid,:username,:password);";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->bindValue("username",$usuario);
        $sql->bindValue("password",$senha);
        $sql->execute();
    }
    public function remover_client_api($idCliente,$idApi){
        $Conexao    = Conexao::getConnection();
        $contar="DELETE FROM CLIENTAPI WHERE CLIENTID = :clientid AND APIID = :apiid;";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente,PDO::PARAM_INT);
        $sql->bindValue("apiid",$idApi,PDO::PARAM_INT);
        $sql->execute();
    }
    public function iniciar_config(){
        require 'Conexao/Conexao.php';
if(!isset($_SESSION["idusuario"])){
    header('Location: login.php?s=c');
    exit();
}
$this->idusuario=$_SESSION["idusuario"];
    }
    public function getIdusuario(){
        return $this->idusuario;
    }
    public function retornar_apis_nao_registradas(){
        $apis=$this->receber_apis();
$apiids=$this->receber_clients_api($this->idusuario);
$contador=0;
$vetor=array();
foreach($apis as $api){
  $i=1;
  foreach($apiids as $apiid){
      if($api['ID']==$apiid['APIID']){
          $i=0;
      }
  }
  if($i){
      $vetor[$contador]=$api;
      $contador++;
  }
}
return $vetor;
    }
    public function receber_selecionado($vetor){
        return isset($_POST['seleciona']) ? $_POST['seleciona']:$vetor[0]['ID'];
    }
    public function funcoes_inserir_remover($recebeu){
$recebeu2=isset($_POST['user']) ? $_POST['user']:'';
$recebeu3=isset($_POST['remover']) ? $_POST['remover']:'';
if(!empty($recebeu2) || !empty($recebeu3)){
  if($recebeu2)
    $this->inserir_client_api($this->idusuario,$recebeu,$_POST['user'],$_POST['password']);
  if(!empty($recebeu3))
    $this->remover_client_api($this->idusuario,intval($recebeu3));
}
    }
    public function retornar_options($vetor,$recebeu){
        $options='';
        foreach($vetor as $api){
            $id=$api['ID'];
            $name=$api['NAME'];
            if($id==$recebeu){
                $options .= "<option value='$id' selected>$name</option>";
            }else{
                $options .= "<option value='$id'>$name</option>";
            }
        }
        return $options;
    } 
    public function retornar_provedores_cliente(){
        $c=0;
        $provedores='';
        $apiids=$this->receber_clients_api($this->idusuario);
        foreach($apiids as $apiid){
            $c++;
            $id=$apiid['APIID'];
            $r=$this->receber_nome_api($id);
            $username=$apiid['USERNAME'];
            $password=$apiid['PASSWORD'];
            $provedores .= "<tr>
                <th scope='row'>$c</th>
                <td>$r</td>
                <td>$username</td>
                <td>$password</td>
                <td>
                    <ul class='list-inline m-0'>
                        <li class='list-inline-item'>
                            <form action='entrarConfig.php' method='post'>
                            <button class='btn btn-danger btn-sm rounded-0' type='submit' data-toggle='tooltip' data-placement='top' title='Remover' name='remover' value='$id'><i class='fa fa-trash'></i></button>
                            </form>
                        </li>
                    </ul>
                </td>
                </tr>";
}
return $provedores;
    }
}
?>