<?php
require 'banco/Model/ClientPlan.php';
require 'banco/View/ViewDetalhes.php';
class ControllerDetalhes{
    private $clientPlan;
    public function inicia_detalhes(){
        $this->clientPlan=new ClientPlan();
        $this->clientPlan->iniciar_detalhes();
    }
    public function mostrar_dados(){
        $viewDetalhes=new ViewDetalhes();
        $html=$viewDetalhes->definir_detalhes();
        $plano=$this->clientPlan->plano($this->clientPlan->getIdusuario());
        $html=$viewDetalhes->alterar(Conexao::receber_nome_cliente($this->clientPlan->getIdusuario()),$html,'{name}');
        $html=$viewDetalhes->alterar($this->clientPlan->receber_options_detalhes(),$html,'{optionsdetalhes}');
        try{
            if(!$plano)
            throw new Exception('Não foi possível encontrar um plano relacionado a sua conta!');
          }catch(Exception $e){
            echo $e->getMessage();
          }
        if($plano){
        $html=$viewDetalhes->alterar($plano['NAME'],$html,'{planname}');
        $html=$viewDetalhes->alterar($plano['PRICE'],$html,'{price}');
        $html=$viewDetalhes->alterar($plano['PRICE']/$plano['REQUESTQUANTITY'],$html,'{valorRequisicao}');
        $html=$viewDetalhes->alterar($this->clientPlan->quantidade_extra($this->clientPlan->selecionado(1),$plano['REQUESTQUANTITY']),$html,'{quantidadeExtra}');
        $html=$viewDetalhes->alterar($plano['REQUESTQUANTITY'],$html,'{quantidadeContratada1}');
        $html=$viewDetalhes->alterar($this->clientPlan->quantidade_disponivel($this->clientPlan->selecionado(1),$plano['REQUESTQUANTITY']),$html,'{quantidadeDisponivel1}');
        $html=$viewDetalhes->alterar($this->clientPlan->total($this->clientPlan->selecionado(1),$plano['REQUESTQUANTITY'],$plano,$this->clientPlan->quantidade_extra($this->clientPlan->selecionado(1),$plano['REQUESTQUANTITY'])),$html,'{total1}');
        $html=$viewDetalhes->alterar($this->clientPlan->receber_sms_credits($this->clientPlan->getIdusuario()),$html,'{smsCredits}');
        $html=$viewDetalhes->alterar($this->clientPlan->quantidade_disponivel($this->clientPlan->selecionado(0),$this->clientPlan->receber_sms_credits($this->clientPlan->getIdusuario())),$html,'{QuantidadeDisponivel2}');
        $html=$viewDetalhes->alterar($this->clientPlan->receber_sms_credits($this->clientPlan->getIdusuario())*0.1,$html,'{total2}');    
        }

        $html=$viewDetalhes->alterar($this->clientPlan->selecionado(1),$html,'{quantidadePlano1}');
        $html=$viewDetalhes->alterar($this->clientPlan->selecionado(0),$html,'{quantidadePlano2}');
        $html=$viewDetalhes->alterar($this->clientPlan->getMes(),$html,'{mes}');
        $viewDetalhes->mostrar($html);
}
}
?>