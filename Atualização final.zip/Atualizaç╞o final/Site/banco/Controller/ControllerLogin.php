<?php 
    require 'banco/Model/Client.php';
    require 'banco/View/ViewLogin.php';
  class ControllerLogin{
      private $client;
      public function preparar_login(){
        $this->client=new Client();
          $this->client->iniciar_login();
      }
      public function mostrar_mensagem_erro(){
        $viewLogin=new ViewLogin();
        $this->client=new Client();
        $viewLogin->mostrar_erro($this->client->verificar_login());
      }
  }
?>