<?php
require 'banco/Model/Client.php';
require 'banco/View/ViewRecuperar.php';
class ControllerRecuperar{
    private $client;
    public function inicia_recuperar(){
        $this->client=new Client();
        $this->client->iniciar_recuperar();
        $this->client->enviar_email();
    }
    public function mostrar_dados(){
        $viewRecuperar=new ViewRecuperar();
        $viewRecuperar->mostrar_aviso($this->client->mostrar_aviso_recuperar());
    }
}
?>