<?php 
    require 'banco/Model/ClientPlan.php';
    require 'banco/View/ViewDashboard.php';
  class ControllerDashboard{
      private $clientPlan;
      public function preparar_index(){
        $this->clientPlan=new ClientPlan();
          $this->clientPlan->iniciar_index();
      }
      public function mostrar_dados(){
        $viewDashboard=new ViewDashboard();
        $html=$viewDashboard->definir_index();
        $plano=$this->clientPlan->plano($this->clientPlan->getIdusuario());
        try{
          if(!$plano)
          throw new Exception('Não foi possível encontrar um plano relacionado a sua conta!');
        }catch(Exception $e){
          echo $e->getMessage();
        }
        if($plano){
        $html=$viewDashboard->alterar($plano['PRICE'],$html,'{preco}');
        $html=$viewDashboard->alterar($plano['REQUESTQUANTITY'],$html,'{quantidadeContratada2}');
        $html=$viewDashboard->alterar($this->clientPlan->quantidade_extra($this->clientPlan->receberQuantidadePlano($this->clientPlan->getIdusuario(),1),$plano['REQUESTQUANTITY']),$html,'{quantidadeExtra2}');
        $html=$viewDashboard->alterar($plano['NAME'],$html,'{planName}');
        $precoChamada=$plano['PRICE']/$plano['REQUESTQUANTITY'];
        $html=$viewDashboard->alterar($precoChamada,$html,'{valorChamada}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_sms_credits($this->clientPlan->getIdusuario()),$html,'{quantidadeContratada1}');
        }
        $html=$viewDashboard->alterar($this->clientPlan->receberQuantidadePlano($this->clientPlan->getIdusuario(),0),$html,'{quantidadePlan1}');
        $html=$viewDashboard->alterar($this->clientPlan->receberQuantidadePlano($this->clientPlan->getIdusuario(),1),$html,'{quantidadePlan2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),0)),$html,'{domingo1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),1)),$html,'{segunda1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),2)),$html,'{terca1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),3)),$html,'{quarta1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),4)),$html,'{quinta1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),5)),$html,'{sexta1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),0,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),6)),$html,'{sabado1}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),0)),$html,'{domingo2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),1)),$html,'{segunda2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),2)),$html,'{terca2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),3)),$html,'{quarta2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),4)),$html,'{quinta2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),5)),$html,'{sexta2}');
        $html=$viewDashboard->alterar($this->clientPlan->receber_contagem_dia_semana($this->clientPlan->getIdusuario(),1,$this->clientPlan->rebeber_dias_semana($this->clientPlan->receber_dia_semana(),6)),$html,'{sabado2}');
        $html=$viewDashboard->alterar(Conexao::receber_nome_cliente($this->clientPlan->getIdusuario()),$html,'{name}');
        $viewDashboard->mostrar($html);
        
      }
  }
?>