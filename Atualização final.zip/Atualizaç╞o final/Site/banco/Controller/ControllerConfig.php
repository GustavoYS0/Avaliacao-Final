<?php
require 'banco/Model/ClientApi.php';
require 'banco/View/ViewConfig.php';
class ControllerConfig{
    private $clientApi;
    public function inicia_config(){
        $this->clientApi=new ClientApi();
        $this->clientApi->iniciar_config();
        $this->clientApi->funcoes_inserir_remover($this->clientApi->receber_selecionado($this->clientApi->retornar_apis_nao_registradas()));
    }
    public function mostrar_dados(){
        $viewConfig=new ViewConfig();
        $html=$viewConfig->definir_config();
        $html=$viewConfig->alterar(Conexao::receber_nome_cliente($this->clientApi->getIdusuario()),$html,'{name}');
        $html=$viewConfig->alterar($this->clientApi->retornar_options($this->clientApi->retornar_apis_nao_registradas(),$this->clientApi->receber_selecionado($this->clientApi->retornar_apis_nao_registradas())),$html,'{options}');
        $html=$viewConfig->alterar($this->clientApi->retornar_provedores_cliente(),$html,'{provedores}');
        $viewConfig->mostrar($html);
    }
}
?>