<?php
require 'banco/Controller/ControllerConfig.php';
$controllerConfig=new ControllerConfig();
$controllerConfig->inicia_config();
$controllerConfig->mostrar_dados();
?>