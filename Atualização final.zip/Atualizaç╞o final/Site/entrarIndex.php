<?php
require 'banco/Controller/ControllerDashboard.php';
$controllerDashboard=new ControllerDashboard();
$controllerDashboard->preparar_index();
$controllerDashboard->mostrar_dados();
?>