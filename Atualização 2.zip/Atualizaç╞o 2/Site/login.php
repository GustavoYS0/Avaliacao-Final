<?php require 'Client.php';
    define('DB_HOST'        , "DESKTOP-5JQEKGD\SQLEXPRESS");
    define('DB_USER'        , "adm");
    define('DB_PASSWORD'    , "adm");
    define('DB_NAME'        , "sqlBD");
    define('DB_DRIVER'      , "sqlsrv"); 
    $client=new Client();
    if(isset($_GET['c'])){
      setcookie( "auth",null,time()-1);
      session_unset ( );
    }else if($client->procurarAcesso()){
        header('Location: index.php');
        exit();
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  

  <title>Login | Expresso API</title>

  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <link href="css/expressoapi.css" rel="stylesheet">

</head>

<body class="bg-gradiente-um">

  <div class="container">

    
    <div class="linha justificado-conteudo-centro">

      <div class="c1 c2 c3">

        <div class="card obj-escondido borda0 sombra-login margem5">
          <div class="card-corpo padd0">
           
            <div class="linha">
              <div class="c4 d-none d-lg-block bg-login-imagem"></div>
              <div class="c4">
                <div class="padd1">
                  <div class="texto-centro">
                    <h1 class="h4 texto-cinza-9 margem4">Bem vindo!</h1>
                    <?php if(isset($_GET['msg'])){ ?> 
                    <p style="color:red"> <?php echo $_GET['msg']; ?> </p>
                    <?php } ?>
                  </div>
                  <form class="user" action="logar.php" method="post">
                    <div class="form-group">
                      <input type="email" name="email" class="form-control form-control-user" id="InserirEmail" placeholder="Digite seu e-mail...">
                    </div>
                    <div class="form-group">
                      <input type="password" name="password" class="form-control form-control-user" id="InserirSenha" placeholder="Digite sua senha...">
                    </div>
                    <div class="form-group">
                      <div class="custom-control custom-checkbox pqno">
                        <input type="checkbox" class="custom-control-input" id="customCheck" name="lembrar">
                        <label class="custom-control-label" for="customCheck">Lembrar meu acesso</label>
                      </div>
                      <br>
                        <center>
                          <input type="submit" value="Login" class="btn btn-primeiro btn-user btn-block"/>
                        </center>
                  </form>
                  <hr>
                  <div class="texto-centro">
                    <a class="pqno" href="recuperarsenha.php">Esqueceu sua senha?</a>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>


  <script src="vendor/jquery/jquery.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.js"></script>


  <script src="vendor/jquery-easing/jquery.easing.js"></script>

 
  <script src="javascript/expressoapi.js"></script>

</body>
</html>