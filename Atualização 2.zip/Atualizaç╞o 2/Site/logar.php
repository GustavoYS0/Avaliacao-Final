<?php

if(isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password'])){
    require 'Client.php';
    define('DB_HOST'        , "DESKTOP-5JQEKGD\SQLEXPRESS");
    define('DB_USER'        , "adm");
    define('DB_PASSWORD'    , "adm");
    define('DB_NAME'        , "sqlBD");
    define('DB_DRIVER'      , "sqlsrv");
    $client=new Client();
    $email=addslashes($_POST['email']);
    $password=addslashes($_POST['password']);
    if($client->login($email,$password)){
        if(isset($_SESSION['idusuario'])){
            $lembrar = ( isset($_POST['lembrar']) ) ? true : null;
            if($lembrar){
                $client->lembrarAcesso();
            }
            header("Location: index.php");
        }else{
            $msg='Sessão expirada!';
            header("Location: login.php?msg=$msg");
        }
    }else{
        $msg='E-mail ou senha inválido(s)!';
        header("Location: login.php?msg=$msg");
    }
}else{
    $msg='Adicione os campos de login e senha primeiro para poder acessar!';
    header("Location: login.php?msg=$msg");
}
?>