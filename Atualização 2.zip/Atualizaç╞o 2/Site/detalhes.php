<?php 
if(!isset($_SESSION["idusuario"])){
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Configurações | Expresso API</title>

  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/expressoapiconfig.css" rel="stylesheet">
  <link href="css/expressoapi.css" rel="stylesheet">
  <style type="text/css">




.ui-w-80 {
width: 80px !important;
height: auto;
}

.btn-default {
border-color: rgba(24,28,33,0.1);
background: rgba(0,0,0,0);
color: #4E5155;
}

.btn-default:hover {
border-color: rgba(24,28,33,0.1);
background: #faeded;
color: #6e6f70;
}

label.btn {
margin-bottom: 0;
}

.btn-outline-primary {
border-color: #cd3232;
background: transparent;
color: #cd3232;
}

.btn-outline-primary:hover {
border-color: #cd3232;
background: #cd3232;
color: #fff;
}

.btn {
cursor: pointer;
}

.text-light {
color: #babbbc !important;
}

.btn-facebook {
border-color: rgba(0,0,0,0);
background: #3B5998;
color: #fff;
}

.btn-instagram {
border-color: rgba(0,0,0,0);
background: #000;
color: #fff;
}

.card {
background-clip: padding-box;
box-shadow: 0 1px 4px rgba(24,28,33,0.012);
}

.row-bordered {
overflow: hidden;
}

.account-settings-fileinput {
position: absolute;
visibility: hidden;
width: 1px;
height: 1px;
opacity: 0;
}
.account-settings-links .list-group-item.active {
font-weight: bold !important;
}
html:not(.dark-style) .account-settings-links .list-group-item.active {
background: transparent !important;
}
.account-settings-multiselect ~ .select2-container {
width: 100% !important;
}
.light-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24, 28, 33, 0.03) !important;
}
.light-style .account-settings-links .list-group-item.active {
color: #4e5155 !important;
}
.material-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24, 28, 33, 0.03) !important;
}
.material-style .account-settings-links .list-group-item.active {
color: #4e5155 !important;
}
.dark-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(255, 255, 255, 0.03) !important;
}
.dark-style .account-settings-links .list-group-item.active {
color: #fff !important;
}
.light-style .account-settings-links .list-group-item.active {
color: #4E5155 !important;
}
.light-style .account-settings-links .list-group-item {
padding: 0.85rem 1.5rem;
border-color: rgba(24,28,33,0.03) !important;
}



</style>

</head>

<body id="page-top">

  <div id="wrapper">

    <ul class="barranav bg-gradiente-um painel painel-negro accordion" id="accordionPainel">


      <a class="painel-marca d-flex alinha-item-centro justificado-conteudo-centro" href="index.html">
        <div class="painel-marca-icon ">
          <i class="fas fa-truck"></i>
        </div>
        <div class="painel-marca-texto margem3">Expresso API </div>
      </a>

      <hr class="painel-divisor margem0">

      <li class="nav-item active">
        <a class="nav-link" href="index.html">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>Dashboard</span></a>
      </li>

      <hr class="painel-divisor">
      
      <div class="painel-titulo">
        Opções
     
      <li class="nav-item">
        <a class="nav-link collapsed" href="config.html">
          <i class="fas fa-fw fa-cog"></i>
          <span>Configurações</span>
        </a>
        <a class="nav-link collapsed" href="login.html">
          <i class="fas fa-sign-out-alt"></i>
          <span>Log out</span>
        </a>
      </li>

      <hr class="painel-divisor nenhum md-block">

    </ul>
   
    <div id="content-wrapper" class="d-flex col-flex">

      <div id="content">

        <nav class="navbar navbar-expand navbar-light bg-branco topbar margem4 static-top sombra">

          <ul class="barranav margem1-auto">

            <li class="nav-item semseta margem1-1">
              <a class="nav-link " href="#" id="alertsDropdown" role="button" data-togglmd-e="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>

                <span class="badge badge-danger badge-counter">1</span>
              </a>
            </li>

            <li class="nav-item semseta margem1-1">
              <a class="nav-link" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
          
                <span class="badge badge-danger badge-counter">9+</span>
              </a>
            </li>

            <div class="topbar-divisor nenhum d-sm-block"></div>

            <li class="nav-item semseta">
              <a class="nav-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="margem2-1 nenhum d-lg-nalinha texto-cinza-6 pqno">Usuário Teste</span>
                <img class="img-profile circuloarred" src="imagens/img.jpg">
              </a>
            </li>
          </ul>
        </nav>
  
        <div class="container light-style flex-grow-1 container-p-y">

          <h1 class="h3 margem0-1 texto-cinza-8">Detalhes</h1>
          <br>
        
          <div class="card overflow-hidden">
            <div class="row no-gutters row-bordered row-border-light">
              
                
              </div>
                <div class="col-md-3">
                  <div class="tab-content">
                    <div class="tab-pane fade active show" id="account-general">
                      <div class="card-body pb-2">
                        <div class="form-group">
                          <label class="form-label">Selecione abaixo o mês e o ano:</label>
                          <select class="custom-select">
                          
                            <option selected="">Janeiro - 2020</option>
                            <option>Fevereiro - 2020</option>
                            <option>Março - 2020</option>
                            <option>Abril - 2020</option>
                          </select>
                        </div></div>
                    </div>
                    </div></div>
                    <div class="card-body pb-2">
                        <div class="linha">
                            <div class="c3 margem4">
                              <div class="card bg-danger texto-branco sombra">
                                <div class="card-corpo">
                                  Detalhes do meu plano SMS em
                                  <div class="texto-branco-50">Janeiro - 2020 </div> 
                                  </div>
                                  
                              </div>
                              <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                                    <tr>
                                      <th class="margem0 font-negrito texto-primeiro">Nome</th>
                                      <th class="margem0 font-negrito texto-primeiro">Valor Mensal</th>
                                      <th class="margem0 font-negrito texto-primeiro">Valor Adicional</th>
                                      <th class="margem0 font-negrito texto-primeiro">Qtde. Máxima Extra</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>APP20</td>
                                      <td>R$ 500,00</td>
                                      <td>R$ 0,10</td>
                                      <td>1000</td>
                                    </tr>
                                </table></div></div>
                                <div class="c5 margem4">
                                <div class="card bg-danger texto-branco sombra">
                                    <div class="card-corpo">
                                      Meu uso
                                     </div></div>
                                     <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                          <thead>
                                            <tr>
                                              <th class="margem0 font-negrito texto-primeiro">Quantidade</th>
                                              <th class="margem0 font-negrito texto-primeiro">Usados</th>
                                              <th class="margem0 font-negrito texto-primeiro">Disponíveis</th>
                                              <th class="margem0 font-negrito texto-primeiro">Extras</th>
                                              <th class="margem0 font-negrito texto-primeiro">Valor Mensal</th>
                                              <th class="margem0 font-negrito texto-primeiro">Valor Adicional por Extra</th>
                                              <th class="margem0 font-negrito texto-primeiro">Valor Total</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <tr>
                                              <td>10.000</td>
                                              <td>0</td>
                                              <td>10.000</td>
                                              <td>1000</td>
                                              <td>R$ 500,00</td>
                                              <td>R$ 0,10</td>
                                              <td>R$ 500,00</td>
                                            </tr>
                                        </table></div>
                            </div>
                          </div>
                          </div>
                    
                    
                  
                
              
            
        </div><div>
        </div>
        
          </div>
      </div>
              


      
      <footer class="adesivo-rodape bg-branco">
        <div class="container margem-auto1">
          <div class="copyright texto-centro my-auto">
            <span>Copyright &copy; Expresso API 2020</span>
          </div>
        </div>
      </footer>

    </div>

  </div>

  <a class="scroll-to-top arredondado" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>



  <script src="vendor/jquery/jquery.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.js"></script>
  <script src="javascript/expressoapi.js"></script>
  <script src="javascript/expressoapiconfig.js"></script>
  <script src="javascript/BSexpressoapiconfig.js"></script>
  <script src="javascript/removeitem.js"></script>
  <script type="text/javascript">

  </script>

</body>

</html>
