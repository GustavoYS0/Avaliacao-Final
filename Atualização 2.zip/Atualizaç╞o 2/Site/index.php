<?php
define('DB_HOST'        , "DESKTOP-5JQEKGD\SQLEXPRESS");
    define('DB_USER'        , "adm");
    define('DB_PASSWORD'    , "adm");
    define('DB_NAME'        , "sqlBD");
    define('DB_DRIVER'      , "sqlsrv");
    require 'Conexao.php';
if(!isset($_SESSION["idusuario"])){
    header('Location: login.php');
    exit();
}
require 'ClientPlan.php';
$idusuario=$_SESSION["idusuario"];
$plan=new ClientPlan();
$dados1=$plan->plano($idusuario,0);
$dados2=$plan->plano($idusuario,1);
$quantidadePlan1=$plan->receberQuantidadePlano($idusuario,$dados1['ID']);
$quantidadePlan2=$plan->receberQuantidadePlano($idusuario,$dados2['ID']);
$quantidadeContratada1=$dados1['CONTRACTEDQUANTITY'];
$quantidadeExtra1=$dados1['EXTRAQUANTITY'];
$quantidadeContratada2=$dados2['CONTRACTEDQUANTITY'];
$quantidadeExtra2=$dados2['EXTRAQUANTITY'];
date_default_timezone_set('America/Sao_Paulo');
$diasemana_numero=date('w',strtotime(date('Y-m-d')));
if($diasemana_numero==0){
  $domingo=0;
  $segunda=1;
  $terca=2;
  $quarta=3;
  $quinta=4;
  $sexta=5;
  $sabado=6;
}else if($diasemana_numero==1){
  $domingo=-1;
  $segunda=0;
  $terca=1;
  $quarta=2;
  $quinta=3;
  $sexta=4;
  $sabado=5;
}else if($diasemana_numero==2){
  $domingo = -2;
  $segunda = -1;
  $terca=0;
  $quarta=1;
  $quinta=2;
  $sexta=3;
  $sabado=4;
}else if($diasemana_numero==3){
  $domingo=-3;
  $segunda=-2;
  $terca=-1;
  $quarta=0;
  $quinta=1;
  $sexta=2;
  $sabado=3;
}else if($diasemana_numero==4){
  $domingo=-4;
  $segunda=-3;
  $terca=-2;
  $quarta=-1;
  $quinta=0;
  $sexta=1;
  $sabado=2;
}else if($diasemana_numero==5){
  $domingo=-5;
  $segunda=-4;
  $terca=-3;
  $quarta=-2;
  $quinta=-1;
  $sexta=0;
  $sabado=1;
}else{
  $domingo=-6;
  $segunda=-5;
  $terca==-4;
  $quarta=-3;
  $quinta=-2;
  $sexta=-1;
  $sabado=0;
}
$domingo1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$domingo);
$segunda1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$segunda);
$terca1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$terca);
$quarta1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$quarta);
$quinta1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$quinta);
$sexta1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$sexta);
$sabado1=$plan->receber_contagem_dia_semana($idusuario,$dados1['ID'],$sabado);
$domingo2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$domingo);
$segunda2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$segunda);
$terca2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$terca);
$quarta2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$quarta);
$quinta2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$quinta);
$sexta2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$sexta);
$sabado2=$plan->receber_contagem_dia_semana($idusuario,$dados2['ID'],$sabado);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Dashboard | Expresso API</title>

  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <link href="css/expressoapi.css" rel="stylesheet">


</head>

<body id="page-top">

  <div id="wrapper">

    <ul class="barranav bg-gradiente-um painel painel-negro accordion" id="accordionPainel">


      <a class="painel-marca d-flex alinha-item-centro justificado-conteudo-centro" href="index.html">
        <div class="painel-marca-icon ">
          <i class="fas fa-truck"></i>
        </div>
        <div class="painel-marca-texto margem3">Expresso API </div>
      </a>

      <hr class="painel-divisor margem0">

      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>Dashboard</span></a>
      </li>

      <hr class="painel-divisor">
      
      <div class="painel-titulo">
        Opções
     
      <li class="nav-item">
        <a class="nav-link collapsed" href="config.html">
          <i class="fas fa-fw fa-cog"></i>
          <span>Configurações</span>
        </a>
        <a class="nav-link collapsed" href="login.php?c=1">
          <i class="fas fa-sign-out-alt"></i>
          <span>Log out</span>
        </a>
      </li>

      <hr class="painel-divisor nenhum md-block">

    </ul>
   
    <div id="content-wrapper" class="d-flex col-flex">

      <div id="content">

        <nav class="navbar navbar-expand navbar-light bg-branco topbar margem4 static-top sombra">

          <ul class="barranav margem1-auto">

            <li class="nav-item semseta margem1-1">
              <a class="nav-link " href="#" id="alertsDropdown" role="button" data-togglmd-e="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>

                <span class="badge badge-danger badge-counter">1</span>
              </a>
            </li>

            <li class="nav-item semseta margem1-1">
              <a class="nav-link" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
          
                <span class="badge badge-danger badge-counter">9+</span>
              </a>
            </li>

            <div class="topbar-divisor nenhum d-sm-block"></div>

            <li class="nav-item semseta">
              <a class="nav-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="margem2-1 nenhum d-lg-nalinha texto-cinza-6 pqno">Usuário Teste</span>
                <img class="img-profile circuloarred" src="imagens/img.jpg">
              </a>
          
            </li>

          </ul>

        </nav>
  
        <div class="containerb">

          <div class="d-sm-flex alinha-item-centro justifica-conteudo-entre margem4">
            <h1 class="h3 margem0-1 texto-cinza-8">Dashboard</h1>
            
          </div>

          <div class="linha">

            <div class="c9">
              <div class="card sombra margem4">
               
                <div class="card-cabecalho padd3 d-flex flex-row alinha-item-centro justifica-conteudo-entre">
                  <h6 class="margem0 font-negrito texto-primeiro"><a href="detalhes.php"> Número diário de SMS</a></h6>
        
                </div>
              
                <div class="card-corpo">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
              </div>
            </div>

          
            <div class=" c11">
              <div class="card sombra margem4">
                
                <div class="card-cabecalho py-3 d-flex flex-row alinha-item-centro justifica-conteudo-entre">
                  <h6 class="margem0 font-negrito texto-primeiro"><a href="detalhes.html">SMS</a></h6>
                 
                </div>
                <!-- Card Body -->
                <div class="card-corpo">
                  <div class="chart-pie pt-4 pb-2">
                    <canvas id="myPieChart"></canvas>
                  </div>
                  <div class="mt-4 texto-centro pqno">
                    <span class="mr-2"><br>
                      <i class="fas fa-circle texto-primeiro"></i> Contratado
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle texto-danger"></i> Utilizado
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle texto-warning"></i> Extras
                    </span><br><br>
                    <h6 class="margem0 font-negrito texto-primeiro">Resumo do Plano de SMS</h6>
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th class="margem0 font-negrito texto-primeiro"> Nome do Plano</th>
                            <th class="margem0 font-negrito texto-primeiro">Valor Mensal</th>
                            <th class="margem0 font-negrito texto-primeiro">Valor por mensagem</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><?php echo $dados1['NAME']; ?></td>
                            <td><?php
                            $plan->padronizar($dados1['MONTHLYVALUE']);
                            ?></td>
                            <td><?php
                            $plan->padronizar($dados1['REQUESTVALUE']);
                            ?></td></td>
                            
                          </tr>
                      </table></div>

                  </div>
                </div>
              </div>
            </div>
          </div>

          
     



          <div class="linha">
            <div class="c5 margem4">
              <div class="card bg-danger texto-branco sombra">
                <div class="card-corpo">
                  
                </div>
              </div>
            </div>
          </div>
          
          
                    


          <div class="linha">

            <div class="c9">
              <div class="card sombra margem4">

                <div class="card-cabecalho padd3 d-flex flex-row alinha-item-centro justifica-conteudo-entre">
                  <h6 class="margem0 font-negrito texto-primeiro"><a href="detalhes.html">Número diário de CHAMADAS</a></h6>
        
                </div>

                <div class="card-corpo">
                  <div class="chart-area">
                    <canvas id="myAreaChart2"></canvas>
                  </div>
                </div>
              </div>
            </div>

     
            <div class=" c11">
              <div class="card sombra margem4">

                <div class="card-cabecalho py-3 d-flex flex-row alinha-item-centro justifica-conteudo-entre">
                  <h6 class="margem0 font-negrito texto-primeiro"><a href="detalhes.html">CHAMADAS EXCEDENTES</a></h6>
                 
                </div>
        
                <div class="card-corpo">
                  <div class="chart-pie pt-4 pb-2">
                    <canvas id="myPieChart2"></canvas>
                  </div>
                  <div class="mt-4 texto-centro pqno">
                    <span class="mr-2"><br>
                      <i class="fas fa-circle texto-primeiro"></i> Contratado
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle texto-danger"></i> Utilizado
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-circle texto-warning"></i> Extras
                    </span><br><br>
                    <h6 class="margem0 font-negrito texto-primeiro">Resumo do Plano de SMS</h6>
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th class="margem0 font-negrito texto-primeiro"> Nome do Plano</th>
                            <th class="margem0 font-negrito texto-primeiro">Valor Mensal</th>
                            <th class="margem0 font-negrito texto-primeiro">Valor por mensagem</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><?php echo $dados2['NAME']; ?></td>
                            <td><?php
                            $plan->padronizar($dados2['MONTHLYVALUE']);
                            ?></td>
                            <td><?php
                            $plan->padronizar($dados2['REQUESTVALUE']);
                            ?></td>
                            
                          </tr>
                      </table></div>

                  </div>
                </div>
              </div>
            </div>
          </div>

          
                    
                    
                                
          
                  </div>
                 
                </div>
      
      <footer class="adesivo-rodape bg-branco">
        <div class="container margem-auto1">
          <div class="copyright texto-centro my-auto">
            <span>Copyright &copy; Expresso API 2020</span>
          </div>
        </div>
      </footer>

    </div>

  </div>

  <a class="scroll-to-top arredondado" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  


  <script src="vendor/jquery/jquery.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.js"></script>

  <script src="vendor/jquery-easing/jquery.easing.js"></script>

  <script src="javascript/expressoapi.js"></script>

  <script src="vendor/chart.js/Chart.js"></script>

  <script>// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

function number_format(number, decimals, dec_point, thousands_sep) {
  // *     example: number_format(1234.56, 2, ',', ' ');
  // *     return: '1 234,56'
  number = (number + '').replace(',', '').replace(' ', '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + Math.round(n * k) / k;
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1).join('0');
  }
  return s.join(dec);
}

// Area Chart Example

var ctx = document.getElementById("myAreaChart");
var myLineChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"],
    datasets: [{
      label: "Enviados",
      lineTension: 0.3,
      backgroundColor: "rgba(238, 32, 32, 0.05)",
      borderColor: "rgba(238, 32, 32, 1)",
      pointRadius: 3,
      pointBackgroundColor: "rgba(186, 11, 11, 1)",
      pointBorderColor: "rgba(186, 11, 11, 1)",
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(230, 65, 65, 1)",
      pointHoverBorderColor: "rgba(230, 65, 65, 1)",
      pointHitRadius: 10,
      pointBorderWidth: 2,
      data: <?php echo "[$segunda1, $terca1, $quarta1, $quinta1, $sexta1, $sabado1, $domingo1]"; ?>,
    }],
  },
  options: {
    maintainAspectRatio: false,
    layout: {
      padding: {
        left: 10,
        right: 25,
        top: 25,
        bottom: 0
      }
    },
    scales: {
      xAxes: [{
        time: {
          unit: 'date'
        },
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          maxTicksLimit: 10
        }
      }],
      yAxes: [{
        ticks: {
          maxTicksLimit: 10,
          padding: 10,
          // Include a dollar sign in the ticks
          callback: function(value, index, values) {
            return '' + number_format(value);
          }
        },
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      intersect: false,
      mode: 'index',
      caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
        }
      }
    }
  }
});
</script>
  <script>
  // Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("myPieChart");
var myPieChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ["Contratado", "Utilizado", "Extras"],
    datasets: [{
      data: [<?php echo "$quantidadeContratada1, $quantidadePlan1, $quantidadeExtra1"; ?>],
      backgroundColor: ['#cd3232', '#e74a3b', '#f6c23e'],
      hoverBackgroundColor: ['#b12525', '#f43f2e', '#efae0b'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});

  </script>
  <script>
  // Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

function number_format(number, decimals, dec_point, thousands_sep) {
  // *     example: number_format(1234.56, 2, ',', ' ');
  // *     return: '1 234,56'
  number = (number + '').replace(',', '').replace(' ', '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + Math.round(n * k) / k;
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1).join('0');
  }
  return s.join(dec);
}

// Area Chart Example
var ctx = document.getElementById("myAreaChart2");
var myLineChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"],
    datasets: [{
      label: "Enviados",
      lineTension: 0.3,
      backgroundColor: "rgba(238, 32, 32, 0.05)",
      borderColor: "rgba(238, 32, 32, 1)",
      pointRadius: 3,
      pointBackgroundColor: "rgba(186, 11, 11, 1)",
      pointBorderColor: "rgba(186, 11, 11, 1)",
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(230, 65, 65, 1)",
      pointHoverBorderColor: "rgba(230, 65, 65, 1)",
      pointHitRadius: 10,
      pointBorderWidth: 2,
      data: [<?php echo "$segunda2,$terca2,$quarta2,$quinta2,$sexta2,$sabado2,$domingo2"; ?>],
    }],
  },
  options: {
    maintainAspectRatio: false,
    layout: {
      padding: {
        left: 10,
        right: 25,
        top: 25,
        bottom: 0
      }
    },
    scales: {
      xAxes: [{
        time: {
          unit: 'date'
        },
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          maxTicksLimit: 10
        }
      }],
      yAxes: [{
        ticks: {
          maxTicksLimit: 10,
          padding: 10,
          // Include a dollar sign in the ticks
          callback: function(value, index, values) {
            return '' + number_format(value);
          }
        },
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      intersect: false,
      mode: 'index',
      caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
        }
      }
    }
  }
});

  </script>
  <script>
  // Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("myPieChart2");
var myPieChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ["Contratado", "Utilizado", "Extras"],
    datasets: [{
      data: [<?php echo "$quantidadeContratada2,$quantidadePlan2,$quantidadeExtra2"; ?>],
      backgroundColor: ['#cd3232', '#e74a3b', '#f6c23e'],
      hoverBackgroundColor: ['#b12525', '#f43f2e', '#efae0b'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});

  </script>

</body>

</html>
