<?php
define('DB_HOST'        , "DESKTOP-5JQEKGD\SQLEXPRESS");
define('DB_USER'        , "adm");
define('DB_PASSWORD'    , "adm");
define('DB_NAME'        , "sqlBD");
define('DB_DRIVER'      , "sqlsrv"); 
require 'Client.php';
//header("Location: recupersenha.php");
$client=new Client();
$email=$_POST['email'];
if($client->verificarEmail($email)){
    $config=$client->verificarEmail($email);
    $client->email($email,$config);
}
$msg='Se o e-mail informado for válido, enviaremos um e-mail com sua nova senha!';
header("Location: recuperarsenha.php?msg=$msg");
?>
