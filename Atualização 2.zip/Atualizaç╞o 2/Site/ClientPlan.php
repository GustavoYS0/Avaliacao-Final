<?php

class ClientPlan{
    public function plano($id,$plan){
        $Conexao    = Conexao::getConnection();
        if($plan){
            $achar="SELECT * FROM ClientPlan WHERE CLIENTID =:clientid AND MONTHLYVALUE != 0;";
        }else{
            $achar="SELECT * FROM ClientPlan WHERE CLIENTID =:clientid AND MONTHLYVALUE = 0;";
        }
        $sql=$Conexao->prepare($achar);
        $sql->bindValue("clientid",$id);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado;
    }
    public function padronizar($valor){
        echo 'R$ ';
        if($valor<1){
            $valor='0'.$valor;
        } 
        $result =str_replace('.',',',$valor);
        echo $result;
    }
    public function receberQuantidadePlano($idCliente,$idPlano){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = :planid AND YEAR(DT_REQUEST) = YEAR(GETDATE()) AND MONTH(DT_REQUEST) = MONTH(GETDATE());";
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("planid",$idPlano);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
    public function receber_contagem_dia_semana($idCliente,$idPlano,$diferenca){
        $Conexao    = Conexao::getConnection();
        $contar="SELECT COUNT(*) FROM ClientApiRequest WHERE CLIENTID =:clientid AND PLANID = :planid AND DAY(DT_REQUEST) = DAY(DATEADD(DAY, :diferenca ,GETDATE())) AND MONTH(DT_REQUEST) = MONTH(DATEADD(DAY, :diferencaa ,GETDATE())) AND YEAR(DT_REQUEST) = YEAR(DATEADD(DAY, :diferencaaa,GETDATE()));";
        //AND MONTH(DT_REQUEST) = MONTH(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)) AND DAY(DT_REQUEST) = DAY(CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103));" CONVERT(DATETIME,DATEADD(DAY, :diferenca ,GETDATE()),103)
        $sql=$Conexao->prepare($contar);
        $sql->bindValue("clientid",$idCliente);
        $sql->bindValue("planid",$idPlano);
        $sql->bindParam("diferenca",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaa",$diferenca,PDO::PARAM_INT);
        $sql->bindParam("diferencaaa",$diferenca,PDO::PARAM_INT);
        $sql->execute();
        $dado=$sql->fetch();
        return $dado[0];
    }
}
?>